<?php
    class Registrar extends DB{
        public function documento(){
            try{
                $stm = parent::conectar()->prepare("SELECT * FROM tipo_documento");

                $stm->execute();
                return $stm->fetchAll(PDO::FETCH_OBJ);
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }

        public function rol(){
            try{
                
                $rol=isset($_REQUEST['rol']) ? $_REQUEST['rol'] : '1';

                if($rol!=2){
                    $stm = parent::conectar()->prepare("SELECT * FROM roles");
                    $stm->execute();
                    return $stm->fetchAll(PDO::FETCH_OBJ);
                }else{
                    $stm = parent::conectar()->prepare("SELECT * FROM roles WHERE id_rol=2");
                    $stm->execute();
                    return $stm->fetchAll(PDO::FETCH_OBJ);
                }
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }
    }
?>