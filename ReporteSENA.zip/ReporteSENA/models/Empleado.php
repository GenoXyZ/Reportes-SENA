<?php

    class Empleado extends DB{
        
        public function index($id){
            try{
                $stm = parent::conectar()->prepare("SELECT * FROM asistencias WHERE fk_usuario='$id' ORDER BY fecha");
                $stm->execute();
                return $stm->fetchAll(PDO::FETCH_OBJ);
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }

        public function store($id,$fecha,$hora_entrada,$descripcion){
            try{
                $stm = parent::conectar()->prepare("INSERT INTO asistencias(fecha,fk_usuario,hora_entrada,descripcion) VALUES('$fecha','$id','$hora_entrada','$descripcion') ");
                $stm->execute();
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }


        public function edit($id){
            try{
                $stm = parent::conectar()->prepare(
                    "SELECT * FROM asistencias
                    WHERE id_asistencia = '$id' ");
                    
                $stm->execute();
                return $stm->fetchAll(PDO::FETCH_OBJ);
            }catch(Exception $e){
                die("Error ...".$e->getMessage());
            }
        }

        public function update($id,$hora_salida,$descripcion){
            try{


                $pr_1 =parent::conectar()->prepare("SELECT hora_entrada FROM asistencias WHERE id_asistencia= '$id' ");
                $pr_1->execute();
                $pr_1 = $pr_1->fetch(PDO::FETCH_OBJ);

                $hora_entrada = $pr_1->hora_entrada;
                
                $hora = explode(':',$hora_entrada);
                $hora_1 = $hora[0];
    
                $hora = explode(':',$hora_salida);
                $hora_2 = $hora[0];

                if($hora_1 >= $hora_2){
                    header("location:?c=empleado&m=editar&id=".$id."&action=error");
                }else{
    
                    $cantidad_horas= $hora_2 - $hora_1;
                    $stm = parent::conectar()->prepare("UPDATE asistencias SET asistencias.hora_salida = '$hora_salida', asistencias.descripcion = '$descripcion', asistencias.cantidad_horas = $cantidad_horas WHERE id_asistencia = '$id' ");
                    $stm->execute();   
                    header("location:?c=empleado&m=asistencia&action=update"); 
                }
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }

    }


?>