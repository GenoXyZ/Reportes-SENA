<?php

    class Administrador extends DB{

        public function index(){
            try{
                $stm = parent::conectar()->prepare("SELECT * FROM usuarios INNER JOIN tipo_documento ON usuarios.fk_tipo_documento= tipo_documento.id_tipo_documento WHERE usuarios.fk_rol = 2 ORDER BY id_usuario");
                $stm->execute();
                return $stm->fetchAll(PDO::FETCH_OBJ);
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }

        public function create($names, $last_names, $email, $password, $documento, $tipo_documento,$rol){
            try{
                $pr_1=parent::conectar()->prepare("SELECT correo FROM usuarios WHERE correo = '$email' ");
                $pr_1->bindParam(1,$email,PDO::PARAM_STR);
                $pr_1->execute();
                $pr_1 = $pr_1->fetch(PDO::FETCH_OBJ);
    
                $pr_2=parent::conectar()->prepare("SELECT documento FROM usuarios WHERE documento = '$documento' ");
                $pr_2->bindParam(1,$email,PDO::PARAM_STR);
                $pr_2->execute();
                $pr_2 = $pr_2->fetch(PDO::FETCH_OBJ);
    
    
                if( $pr_1==$email || $pr_2==$documento){
                    header("location:?c=registrar&m=registrar&action=error");
                }else{
                    $stm = parent::conectar()->prepare("INSERT INTO usuarios(nombres, apellidos, correo, clave, documento, fk_tipo_documento,fk_rol) VALUES('$names', '$last_names', '$email', '$password', '$documento','$tipo_documento','$rol')");
                    $stm->execute();
                    if($rol==1){
                        header("location:?c=administrador&m=home&action=create");
                    }else{
                        header("location:?c=administrador&m=index&action=create");
                    }
                }
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }


        public function edit($id){
            try{
                $stm = parent::conectar()->prepare(
                    "SELECT * FROM usuarios 
                    INNER JOIN tipo_documento ON usuarios.fk_tipo_documento= tipo_documento.id_tipo_documento 
                    INNER JOIN roles ON usuarios.fk_rol = roles.id_rol 
                    WHERE id_usuario = '$id' ");
                    
                $stm->execute();
                return $stm->fetchAll(PDO::FETCH_OBJ);
            }catch(Exception $e){
                die("Error ...".$e->getMessage());
            }
        }

        public function update($id,$names, $last_names, $email, $documento, $tipo_documento){

            $pr_1=parent::conectar()->prepare("SELECT correo FROM usuarios WHERE correo = '$email' AND id_usuario != '$id' ");
            $pr_1->bindParam(1,$email,PDO::PARAM_STR);
            $pr_1->execute();
            $pr_1 = $pr_1->fetch(PDO::FETCH_OBJ);

            $pr_2=parent::conectar()->prepare("SELECT documento FROM usuarios WHERE documento = '$documento' AND id_usuario != '$id' ");
            $pr_2->bindParam(1,$email,PDO::PARAM_STR);
            $pr_2->execute();
            $pr_2 = $pr_2->fetch(PDO::FETCH_OBJ);

            if( $pr_1->correo==$email || $pr_2->documento==$documento){
                header("location:?c=administrador&m=editar&id=".$id."&action=error");
            }else{
                $stm = parent::conectar()->prepare(
                    "UPDATE usuarios SET 
                    nombres = '$names', apellidos = '$last_names', correo = '$email', 
                    documento = '$documento', fk_tipo_documento = '$tipo_documento' 
                    WHERE id_usuario = '$id' ");
                $stm->execute();
                header("location:?c=administrador&m=index&action=update");
            };
        }

        public function destroy($id){
            try{
                $stm = parent::conectar()->prepare("DELETE FROM usuarios WHERE id_usuario = '$id' ");
                $stm->execute();
            }catch(Exception $e){
                die("Error ...".$e->getMessage());
            }
        }
    
        public function documento($doc){
            try{
                $stm = parent::conectar()->prepare("SELECT * FROM tipo_documento WHERE id_tipo_documento != '$doc' ");
                $stm->execute();
                return $stm->fetchAll(PDO::FETCH_OBJ);
            }catch(Exception $e) {
                die("Error ...".$e->getMessage());
            }
        }
    }

?>