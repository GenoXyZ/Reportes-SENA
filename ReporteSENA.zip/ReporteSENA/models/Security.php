<?php

    class Security{
        public function validar_sesion(){
            if(empty($_SESSION['USER']) || is_null($_SESSION['USER'])){
                header("location:?class=login&method=login");
            }
        }
    }

?>