<?php

class Usuario extends DB{
    
    public function requestEmail($email){
        try{
            $stm=parent::conectar()->prepare("SELECT * FROM usuarios 
            INNER JOIN tipo_documento ON usuarios.fk_tipo_documento= tipo_documento.id_tipo_documento 
            INNER JOIN roles ON usuarios.fk_rol = roles.id_rol 
            WHERE correo = ? ");

            $stm->bindParam(1,$email,PDO::PARAM_STR);
            $stm->execute();
            return $stm->fetch(PDO::FETCH_OBJ);
        }catch(Exception $e) {
            die($e->getMessage());
        }
    }

    public function create($names, $last_names, $email, $password, $documento, $tipo_documento,$rol){
        try{
            $pr_1=parent::conectar()->prepare("SELECT correo FROM usuarios WHERE correo = '$email' ");
            $pr_1->bindParam(1,$email,PDO::PARAM_STR);
            $pr_1->execute();
            $pr_1 = $pr_1->fetch(PDO::FETCH_OBJ);

            $pr_2=parent::conectar()->prepare("SELECT documento FROM usuarios WHERE documento = '$documento' ");
            $pr_2->bindParam(1,$email,PDO::PARAM_STR);
            $pr_2->execute();
            $pr_2 = $pr_2->fetch(PDO::FETCH_OBJ);

            $b=isset($_REQUEST['b']) ? $_REQUEST['b'] : 0;

            if( $pr_1->correo==$email || $pr_2->documento==$documento){
                header("location:?c=registrar&m=registrar&b=".$b."&action=error");
            }else{
                $stm = parent::conectar()->prepare("INSERT INTO usuarios(nombres, apellidos, correo, clave, documento, fk_tipo_documento,fk_rol) VALUES('$names', '$last_names', '$email', '$password', '$documento','$tipo_documento','$rol')");
                $stm->execute();
                if($b==1){
                    header("location:?c=administrador&m=home&action=create");
                }else{
                    header("location:?c=administrador&m=index&action=create");
                }
            }
        }catch(Exception $e) {
            die("Error ...".$e->getMessage());
        }
    }

    public function update($id,$names, $last_names, $email, $documento, $tipo_documento,$password){
    
        $pr_1=parent::conectar()->prepare("SELECT correo FROM usuarios WHERE correo = '$email' AND id_usuario != '$id' ");
        $pr_1->bindParam(1,$email,PDO::PARAM_STR);
        $pr_1->execute();
        $pr_1 = $pr_1->fetch(PDO::FETCH_OBJ);

        $pr_2=parent::conectar()->prepare("SELECT documento FROM usuarios WHERE documento = '$documento' AND id_usuario != '$id' ");
        $pr_2->bindParam(1,$email,PDO::PARAM_STR);
        $pr_2->execute();
        $pr_2 = $pr_2->fetch(PDO::FETCH_OBJ);

        if( $pr_1->correo==$email || $pr_2->documento==$documento){
            header("location:?c=usuario&m=perfil&b=.'$b'.action=error");
        }else{
            $stm = parent::conectar()->prepare(
                "UPDATE usuarios SET 
                nombres = '$names', apellidos = '$last_names', correo = '$email', 
                documento = '$documento', fk_tipo_documento = '$tipo_documento', clave = '$password'
                WHERE id_usuario = '$id' ");
            $stm->execute();

            if($_SESSION['USER']->clave != $password){
                $usuario= $this->requestEmail($email);
                $_SESSION['USER']=$usuario;
                header("location:?c=login&m=login&action=update");
            }else{
                header("location:?c=administrador&m=home&action=update");
            }
            
        };
    }

    public function documento($doc){
        try{
            $stm = parent::conectar()->prepare("SELECT * FROM tipo_documento WHERE id_tipo_documento != '$doc' ");
            $stm->execute();
            return $stm->fetchAll(PDO::FETCH_OBJ);
        }catch(Exception $e) {
            die("Error ...".$e->getMessage());
        }
    }
}

?>