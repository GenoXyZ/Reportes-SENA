<?php

    class Login extends DB{
        
    }



?>