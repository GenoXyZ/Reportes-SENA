<?php

    class UsuarioController extends Usuario{
        
        public function perfil(){
            require_once('views/usuario/perfil.php');
          }
      
          public function actualizar_perfil(){
            $id=$_SESSION['USER']->id_usuario;
            $names = $_POST['names'];
            $last_names = $_POST['last_names'];
            $email = $_POST['email'];
            $documento = $_POST['documento'];
            $tipo_documento = $_POST['tipo_documento'];
            $password = $_POST['clave'];
            parent::update($id, $names, $last_names, $email, $documento, $tipo_documento,$password); 
        }
    }

?>