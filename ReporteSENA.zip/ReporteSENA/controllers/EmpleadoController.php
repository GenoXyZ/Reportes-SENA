<?php
    class EmpleadoController extends Empleado{
        private $usuario;

        public function __construct(){
            try{
                $this->usuario = new Usuario();
            }
            catch(Exception $error){
                die("Error found:: ".$error->getMessage());
            }
        }
        public function home(){
            require_once('views/empleado/home.php');
        }

        public function asistencia(){
            require_once('views/empleado/index.php');
        }

        public function crear(){
            require_once('views/empleado/create.php');
        }

        public function registrar(){
            $id = $_SESSION['USER']->id_usuario;
            $fecha = $_POST['fecha'];
            $hora_entrada = $_POST['hora_entrada'];
            $descripcion = $_POST['descripcion'];
            parent::store($id,$fecha,$hora_entrada,$descripcion);
            header("location:?c=empleado&m=asistencia&action=create");
        }

        public function editar(){
            $id= $_REQUEST['id']; 
            $asistencia= parent::edit($id);
            require_once('views/empleado/edit.php');
        }

        public function actualizar(){
            $id=$_REQUEST['id'];
            $hora_salida = $_POST['hora_salida'];
            $descripcion = $_POST['descripcion'];
            parent::update($id,$hora_salida,$descripcion); 
            
        }  
    }
    
    ?>