<?php
    class Securitycontroller extends Security{

        public function salir(){
       //destruye las sesiones iniciadas     
        session_destroy();
        header("location:?Cclass=login&method=login");    
        }

    }


?>