<?php

class AdministradorController extends Administrador{

    private $security;
    private $usuario;
    private $empleado;
    
    public function __construct(){
      try{
         $this->security= new Security();
         $this->security->validar_sesion();
         $this->usuario = new Usuario();
         $this->empleado = new Empleado();
      }catch(Exception $e){
        die($e->getMessage());  
      }
    }
    public function home(){
      require_once('views/administrador/home.php');
    }

    public function index(){
      require_once('views/administrador/index.php');
    }

    public function crear(){
      require_once('views/administrador/create.php');
    }

    public function editar(){
      $id=$_REQUEST['id'];
      $empleado= parent::edit($id);
      require_once('views/administrador/edit.php');
    }

    public function actualizar(){
      $id=$_REQUEST['id'];
      $names = $_POST['names'];
      $last_names = $_POST['last_names'];
      $email = $_POST['email'];
      $documento = $_POST['documento'];
      $tipo_documento = $_POST['tipo_documento'];
      parent::update($id, $names, $last_names, $email, $documento, $tipo_documento); 
    }

    public function delete(){
      $id=$_REQUEST['id'];
      parent::destroy($id);
      header("location:?c=administrador&m=index&action=delete");
    }   

    public function empleado(){
      $asistencias = $this->empleado->index($_REQUEST['id']);
      require_once('views/administrador/empleado.php');
    }
}

?>