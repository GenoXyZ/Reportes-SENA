<?php

class LoginController extends login{

    private $usuario;

    public function __construct(){
        try{
            $this->usuario = new Usuario();
        }catch(Exception $e){
        
        }
    }


    public function login(){
        require_once('views/usuario/login.php');
    }

    public function auth(){
        $correo= $_POST['email'];
        $password= $_POST['password'];
        $usuario= $this->usuario->requestEmail($_POST['email']);
        if($correo==$usuario->correo && $password== $usuario->clave){
            $_SESSION['USER']=$usuario;
            if($usuario->fk_rol==1){
                header("location:?c=administrador&m=home");
            }else{
                header("location:?c=empleado&m=home");
            }
        }else{
            header("location:?c=login&m=login&action=error");
        }
    }
        
}

?>