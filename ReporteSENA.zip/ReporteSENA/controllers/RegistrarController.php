<?php
    class RegistrarController extends Registrar{
        private $usuario;

        public function __construct(){
            try{
                $this->usuario = new Usuario();
            }
            catch(Exception $error){
                die("Error found:: ".$error->getMessage());
            }
        }

        public function registrar(){
            require_once('views/usuario/registrar.php');
        }

        public function registrarUsuario(){
            $names = $_POST['names'];
            $last_names = $_POST['last_names'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $documento = $_POST['documento'];
            $tipo_documento = $_POST['tipo_documento'];
            $rol=$_POST['roles'];

            $this->usuario->create($names, $last_names, $email, $password, $documento, $tipo_documento,$rol);
            
        }

    }


?>