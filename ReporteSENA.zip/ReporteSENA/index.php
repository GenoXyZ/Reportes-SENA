<?php
session_start();
require_once('models/DB.php');
require_once('models/Login.php');
require_once('models/Usuario.php');
require_once('models/Security.php');
require_once('models/Registrar.php');
require_once('models/Administrador.php');
require_once('models/Empleado.php');

$controller=ucwords(isset($_GET['c']) ? $_GET['c'] : 'Login');
$method=ucwords(isset($_GET['m']) ? $_GET['m'] : 'Login');
require_once('controllers/'.$controller.'Controller.php');

$controller=$controller.'Controller';
$objeto= new $controller();
$objeto->$method();

?>