<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/bootstrap.css">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/libs/css/animate.css">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/fontawesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>Registro - SENA</title>
</head>
<body class="fondo">
    <div class="container">
        <?php $action=isset($_REQUEST['action']) ? $_REQUEST['action'] : 'index';?> 
            <?php if($action == "error"){ ?>
                <div class="alert alert-danger animated bounceOut delay-2s" style="position:absolute; width:75%; margin-top:20px;">
                    <p>¡Ha ocurrido un error!</p>
                </div>
            <?php }?>

            <?php if($action == "update"){ ?>
                <div class="alert alert-warning animated bounceOut delay-2s" style="position:absolute; width:75%; margin-top:20px;">
                    <p>¡La anterior sesión ha sido actualizada!</p>
                </div>
            <?php }?>
            
        <div class="row">
            <div class="forma">
                <form class="myform" action="?c=login&m=auth" method="post">
                    <img class="persona" src="assets/libs/img/persona.png" alt="">   
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">   
                            <span class="input-group-text"><i class="fa fa-user-circle"></i></span>
                        </div>
                        <input  name="email" type="email" class="form-control" placeholder="Email" required>
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-lock"></i></span>
                        </div>
                        <input name="password" type="Password" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1" required>
                    </div>
                    <button type="submit" class="btn btn-info btn-block">Conectar</button> 
                </form>
            </div>
        </div>  
    </div>
</body>
</html>
