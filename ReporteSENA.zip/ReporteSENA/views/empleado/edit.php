<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/bootstrap.css">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/libs/css/animate.css">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/fontawesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>Nuevo - Registro</title>
</head>
<body class="fondo">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?c=empleado&m=home">Home</a></li>
                <li class="breadcrumb-item active">Nuevos</li>
            </ol>
        </nav> 
        <?php $action=isset($_REQUEST['action']) ? $_REQUEST['action'] : 'index';?> 
            <?php if($action == "error"){ ?>
                <div class="alert alert-danger animated bounceOut delay-1s" style="position:absolute; width:73%;">
                    <p>¡Las horas ingresadas no coinciden lógicamente!</p>
                </div>
            <?php }?>
        <div class="forma2" align="center">
            <form class="myform" action="?c=empleado&m=actualizar&id=<?php echo $asistencia[0]->id_asistencia?>"  method="post">  
                <h3 style="color:white; font-weight:bold;">Actualizar Asistencia</h3> 
                <hr style="color: white;">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
                    </div>
                    <input type="date" class="form-control" name="fecha" value="<?php echo $asistencia[0]->fecha?>" disabled >
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
                    </div>
                    <input type="time" class="form-control" name="hora_entrada" value="<?php echo $asistencia[0]->hora_entrada?>" disabled>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
                    </div>
                    <input type="time" class="form-control" name="hora_salida" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
                    </div>
                    <textarea name="descripcion" cols="54" rows="3" placeholder="<?php echo $asistencia[0]->descripcion?>"></textarea>                
                </div>
                <button type="submit" class="btn btn-info btn-block">Registrar</button>
            </form>
        </div>
    </div>
</body>
</html>
