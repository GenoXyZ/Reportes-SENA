<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/bootstrap.css">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/libs/css/animate.css">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/fontawesome.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>Empleados</title>
</head>
<body >
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?c=administrador&m=home">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">EMPLEADOS</li>
            </ol>
        </nav>

        <?php $action=isset($_REQUEST['action']) ? $_REQUEST['action'] : 'index';?> 
        <?php if($action == "delete"){ ?>
            <div class="alert alert-danger animated bounceOut delay-2s" style="position:absolute; width:73%;">
                <p>¡Se ha eliminado un elemento de forma Exitosa!</p>
            </div>
        <?php }?>

        <?php if($action == "create"){ ?>
            <div class="alert alert-success animated bounceOut delay-2s" style="position:absolute; width:73%;">
                <p>¡Se ha creado un elemento de forma Exitosa!</p>
            </div>
        <?php }?>

        <?php if($action == "update"){ ?>
            <div class="alert alert-warning animated bounceOut delay-2s" style="position:absolute; width:73%;">
                <p>¡Se ha actualizado un elemento de forma Exitosa!</p>
            </div>
        <?php }?>


        <h3 class="display-2" style="margin-top:100px;">Reporte Empleados</h3>
        <hr>
        <p>Administrador: <?php echo $_SESSION['USER']->nombres;?></p>
        <table class="table table-striped">
            <thead class="thead-dark" align="center">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">FECHA ASISTENCIA</th>
                    <th scope="col">HORA DE ENTRADA</th>
                    <th scope="col">HORA DE SALIDA</th>
                    <th scope="col">HORAS</th>
                    <th scope="col">DESCRIPCIÓN</th>
                    <th><i class="fa fa-pencil-fa fa-eye icon-table" aria-hidden="true"></i></th>
                    <th><i class="fa fa-pencil-square icon-table" aria-hidden="true"></i></th>
                </tr>
            </thead>
            <tbody align="center">
                <?php foreach(parent::index($_SESSION['USER']->id_usuario) as $asistencia){?>
                    <tr>
                        <td><?php echo $asistencia->id_asistencia?></td> 
                        <td><?php echo $asistencia->fecha?></td> 
                        <td><?php echo $asistencia->hora_entrada?></td> 
                        <td><?php echo isset($asistencia->hora_salida) ? $asistencia->hora_salida : '-- --';?></td> 
                        <td><?php echo isset($asistencia->cantidad_horas) ? $asistencia->cantidad_horas : '-- --';?></td> 
                        <td><?php echo $asistencia->descripcion ? $asistencia->descripcion : 'Sin Observación';?></td>
                        <td><a href="" class="btn btn-block btn-info">VER MÁS</a></td>
                        <td><a href="?c=empleado&m=editar&id=<?php echo $asistencia->id_asistencia?>" class="btn btn-block btn-warning">ACTUALIZAR</a></td> 
                   </tr>
                <?php };?>
            </tbody>
        </table>
        <div align="center">
            <a href="?c=empleado&m=crear" class="btn btn-success">CREAR UN NUEVO REGISTRO</a>
        </div>
        <a href="?class=Segurity&method=salir">Cerrar sesion</a>  
    </div>        
</body>
</html>