<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/bootstrap.css">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/libs/css/animate.css">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/fontawesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>Administrador</title>
</head>
<body >
    <div class="container"><br><br>
        <?php $action=isset($_REQUEST['action']) ? $_REQUEST['action'] : 'index';?> 
        <?php if($action == "create"){ ?>
            <div class="alert alert-success animated bounceOut delay-1s" style="position:absolute; width:73%;">
                <p>Creacion Exitosa!</p>
            </div>
        <?php }?>

        <?php if($action == "update"){ ?>
            <div class="alert alert-warning animated bounceOut delay-2s" style="position:absolute; width:73%;">
                <p>¡Su perfil ha sido actualizado con Éxito!</p>
            </div>
        <?php }?>
        
        <h2 class="display-2" style="margin-top:100px">Bienvenido Administrador!</h2><hr>
        <div class="row">
            <div class="col-md-6"><br>
                <p class="lead">Has ingresado Correctamente</p>
                <p>Administrador: <?php echo $_SESSION['USER']->nombres." ".$_SESSION['USER']->apellidos;?></p><br><br>
                <a class="btn btn-primary btn-lg" href="?c=registrar&m=registrar&b=1" role="button">Crear Usuario</a>
                <a class="btn btn-primary btn-lg" href="?c=administrador&m=index" role="button2">Empleados</a>
                <a class="btn btn-primary btn-lg" href="?c=usuario&m=perfil" role="button3">Perfil</a><br>    
                <a href="?class=Segurity&method=salir">Cerrar sesion</a>  
            </div>
            <div class="col-md-6">
                <img class="fondo1" src="assets/libs/img/fondo1.jpg" alt=""> 
            </div>
        </div>
    </div>
</body>
</html>