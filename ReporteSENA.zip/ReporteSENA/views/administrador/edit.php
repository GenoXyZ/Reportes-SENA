<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/bootstrap.css">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/libs/bootstrap-4/css/fontawesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
    <title>Nuevo - Registro</title>
</head>
<body class="fondo">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?c=administrador&m=home">Home</a></li>
                <li class="breadcrumb-item active">Nuevos</li>
            </ol>
        </nav> 
        <?php $action=isset($_REQUEST['action']) ? $_REQUEST['action'] : 'index';?> 
            <?php if($action == "error"){ ?>
                <div class="alert alert-danger animated bounceOut delay-1s" style="position:absolute; width:75%;">
                    <p>¡Ha ocurrido un error! Se han encontrado registros duplicados en la Base de Datos</p>
                </div>
            <?php }?>
        <div class="forma2" align="center">
            <form class="myform" action="?c=administrador&m=actualizar&id=<?php echo $empleado[0]->id_usuario?>" method="post">  
                <h3 style="color:white; font-weight:bold;">Actualizar Usuario</h3> 
                <hr style="color: white;">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
                    </div>
                    <input type="name" class="form-control" name="names" value="<?php echo $empleado[0]->nombres;?>" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
                    </div>
                    <input type="text" class="form-control" name="last_names" value="<?php echo $empleado[0]->apellidos;?>" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-comment-alt"></i></span>
                    </div>
                    <input type="text" class="form-control" name="roles" value="<?php echo $empleado[0]->nombre_rol;?>" disabled>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1">@</span>
                    </div>
                    <input type="email" class="form-control" name="email" value="<?php echo $empleado[0]->correo;?>" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-comment-alt"></i></span>
                    </div>
                   
                    <select name="tipo_documento" class="form-control">
                        <option value="<?php echo $empleado[0]->fk_tipo_documento?>" selected><?php echo $empleado[0]->tipo_documento?></option>
                        <?php foreach(parent::documento($empleado[0]->fk_tipo_documento) as $documento){?>
                            <option value="<?php echo $documento->id_tipo_documento?>"><?php echo $documento->tipo_documento?></option>
                        <?php };?>
                    </select>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-comment-alt"></i></span>
                    </div>
                    <input type="text" class="form-control" name="documento" value="<?php echo $empleado[0]->documento;?>" required>
                </div>
                <button type="submit" class="btn btn-info btn-block">Registrar</button>
            </form>
        </div>
    </div>
</body>
</html>
